-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-11-2019 a las 22:55:42
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `ID_A` int(10) NOT NULL,
  `DNI_A` int(10) NOT NULL,
  `LEGAJO` text,
  `SANCIONES` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`ID_A`, `DNI_A`, `LEGAJO`, `SANCIONES`) VALUES
(17, 39538264, '123123', NULL),
(41, 39415865, '112026', NULL),
(42, 39415866, '112027', NULL),
(43, 39415867, '112028', NULL),
(44, 39415868, '112029', NULL),
(45, 39415869, '112030', NULL),
(46, 39415870, '112031', NULL),
(47, 39415871, '112032', NULL),
(48, 39415872, '112033', NULL),
(49, 39415873, '112034', NULL),
(50, 39415874, '112035', NULL),
(51, 39415875, '112036', NULL),
(52, 39415876, '112037', NULL),
(53, 39415877, '112038', NULL),
(54, 39415878, '112039', NULL),
(55, 39415879, '112040', NULL),
(56, 39415880, '112041', NULL),
(57, 39415881, '112042', NULL),
(58, 39415882, '112043', NULL),
(59, 39415883, '112044', NULL),
(60, 39415884, '112045', NULL),
(61, 39415885, '112046', NULL),
(62, 39415886, '112047', NULL),
(63, 39415887, '112048', NULL),
(64, 39415888, '112049', NULL),
(65, 39415889, '112050', NULL),
(66, 39415890, '112051', NULL),
(67, 39415891, '112052', NULL),
(68, 39415892, '112053', NULL),
(69, 39415893, '112054', NULL),
(70, 39415894, '112055', NULL),
(71, 39415895, '112056', NULL),
(72, 39415896, '112057', NULL),
(73, 39415897, '112058', NULL),
(74, 39415898, '112059', NULL),
(75, 39415899, '112060', NULL),
(76, 39415900, '112061', NULL),
(77, 39415901, '112062', NULL),
(78, 39415902, '112063', NULL),
(79, 39415903, '112064', NULL),
(80, 39415904, '112065', NULL),
(81, 39415905, '112066', NULL),
(82, 39415906, '112067', NULL),
(83, 39415907, '112068', NULL),
(84, 39415908, '112069', NULL),
(85, 39415909, '112070', NULL),
(86, 39415910, '112071', NULL),
(87, 39415911, '112072', NULL),
(88, 39415912, '112073', NULL),
(89, 39415913, '112074', NULL),
(90, 39415914, '112075', NULL),
(91, 39415915, '112076', NULL),
(92, 39415916, '112077', NULL),
(93, 39415917, '112078', NULL),
(94, 39415918, '112079', NULL),
(95, 39415919, '112080', NULL),
(96, 39415920, '112081', NULL),
(97, 39415921, '112082', NULL),
(98, 39415922, '112083', NULL),
(99, 39415923, '112084', NULL),
(100, 39415924, '112085', NULL),
(101, 39415925, '112086', NULL),
(102, 39415926, '112087', NULL),
(103, 39415927, '112088', NULL),
(104, 39415928, '112089', NULL),
(105, 39415929, '112090', NULL),
(106, 0, '', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `ID_CATEGORIA` int(15) NOT NULL,
  `CATEGORIA` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`ID_CATEGORIA`, `CATEGORIA`) VALUES
(1, 'Secretario'),
(2, 'Profesor'),
(3, 'Alumno');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarioxalumno`
--

CREATE TABLE `comentarioxalumno` (
  `ID_COMENTARIO` int(20) NOT NULL,
  `DNI_ALUMNO` int(20) NOT NULL,
  `DESCRIPCION` varchar(255) NOT NULL,
  `FECHA` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `comentarioxalumno`
--

INSERT INTO `comentarioxalumno` (`ID_COMENTARIO`, `DNI_ALUMNO`, `DESCRIPCION`, `FECHA`) VALUES
(1, 39538264, 'Alumno de buen desempeÃ±o y colaboracion', '16/09/2019'),
(2, 39538264, 'Ahora comenzo a portarse mal', '25/09/2019'),
(3, 39415869, 'Buen comportamiento y muy respetuosa', '03/11/2019');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE `curso` (
  `ID_CURSO` int(25) NOT NULL,
  `CURSO` varchar(3) NOT NULL,
  `ALUMNO_DNI` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `curso`
--

INSERT INTO `curso` (`ID_CURSO`, `CURSO`, `ALUMNO_DNI`) VALUES
(1, '1A', 39538264),
(3, '2A', 0),
(4, '2B', 0),
(5, '3A', 0),
(7, '4A', 0),
(8, '4B', 0),
(9, '5A', 0),
(10, '5B', 0),
(11, '1B', 39532147),
(12, '1A', 141516),
(13, '1B', 43529861),
(14, '5B', 469548),
(15, '4B', 8536524),
(16, '3B', 35268745),
(17, '5B', 1548567),
(18, '3A', 395684),
(19, '1B', 101010),
(20, '2B', 1548695),
(21, '1B', 1012530),
(22, '1A', 1012554),
(23, '1B', 1456465),
(24, '2A', 2456466),
(25, '2B', 6456467),
(26, '3A', 5456468),
(27, '3B', 3456469),
(28, '4A', 3456470),
(29, '4B', 1456471),
(30, '5A', 5456472),
(31, '5B', 7456473),
(32, '1A', 39415865),
(33, '1B', 39415866),
(34, '2A', 39415867),
(35, '2B', 39415868),
(36, '3A', 39415869),
(37, '3B', 39415870),
(38, '4A', 39415871),
(39, '4B', 39415872),
(40, '5A', 39415873),
(41, '5B', 39415874),
(42, '1A', 39415875),
(43, '1B', 39415876),
(44, '5A', 39415877),
(45, '2B', 39415878),
(46, '3A', 39415879),
(47, '3B', 39415880),
(48, '4A', 39415881),
(49, '2A', 39415882),
(50, '4B', 39415883),
(51, '5B', 39415884),
(52, '1A', 39415885),
(53, '1B', 39415886),
(54, '4B', 39415887),
(55, '2B', 39415888),
(56, '3A', 39415889),
(57, '3B', 39415890),
(58, '4A', 39415891),
(59, '2A', 39415892),
(60, '5A', 39415893),
(61, '5B', 39415894),
(62, '1A', 39415895),
(63, '1B', 39415896),
(64, '2A', 39415897),
(65, '2B', 39415898),
(66, '3A', 39415899),
(67, '5B', 39415900),
(68, '4A', 39415901),
(69, '4B', 39415902),
(70, '5A', 39415903),
(71, '5B', 39415904),
(72, '1A', 39415905),
(73, '1B', 39415906),
(74, '2A', 39415907),
(75, '2B', 39415908),
(76, '3A', 39415909),
(77, '3B', 39415910),
(78, '4A', 39415911),
(79, '4B', 39415912),
(80, '5A', 39415913),
(81, '5B', 39415914),
(82, '1A', 39415915),
(83, '1B', 39415916),
(84, '4A', 39415917),
(85, '2B', 39415918),
(86, '3A', 39415919),
(87, '3B', 39415920),
(88, '4A', 39415921),
(89, '2A', 39415922),
(90, '4A', 39415923),
(91, '5B', 39415924),
(92, '1A', 39415925),
(93, '1B', 39415926),
(94, '1A', 39415927),
(95, '2B', 39415928),
(96, '3A', 39415929),
(97, '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dias`
--

CREATE TABLE `dias` (
  `ID_DIA` int(11) NOT NULL,
  `DIA` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `dias`
--

INSERT INTO `dias` (`ID_DIA`, `DIA`) VALUES
(1, 'Lunes'),
(2, 'Martes'),
(3, 'Miercoles'),
(4, 'Jueves'),
(5, 'Viernes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados`
--

CREATE TABLE `estados` (
  `ID_ESTADO` int(1) NOT NULL,
  `ESTADO` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estados`
--

INSERT INTO `estados` (`ID_ESTADO`, `ESTADO`) VALUES
(0, 'Inactivo'),
(1, 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horario`
--

CREATE TABLE `horario` (
  `ID_HORARIO` int(11) NOT NULL,
  `RANGO` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `horario`
--

INSERT INTO `horario` (`ID_HORARIO`, `RANGO`) VALUES
(1, '7:30 - 9:30'),
(2, '10:00 - 12:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE `materia` (
  `ID_MATERIA` int(20) NOT NULL,
  `NOMBRE` varchar(25) NOT NULL,
  `ID_HS` int(10) NOT NULL,
  `ID_DIAS` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`ID_MATERIA`, `NOMBRE`, `ID_HS`, `ID_DIAS`) VALUES
(1, 'Historia I', 1, 1),
(2, 'Lengua I', 2, 2),
(3, 'Matematicas I', 2, 4),
(5, 'Ciencias Sociales I', 2, 5),
(6, 'Ingles II', 1, 2),
(7, 'Ciencias Naturales II', 2, 4),
(8, 'Biologia III', 1, 3),
(9, 'Ingles III', 1, 2),
(10, 'Lengua III', 2, 3),
(11, 'Lengua III', 2, 3),
(12, 'Ciencias Sociales I', 2, 5),
(13, 'Geografia 1', 2, 3),
(14, 'HGO', 2, 3),
(15, 'MatemÃ¡ticas III', 2, 3),
(16, 'Historia I', 1, 1),
(17, 'Geografia 1', 2, 3),
(18, 'Geografia 1', 2, 3),
(19, 'Analisis de Sistemas', 2, 4),
(20, 'Seguridad Informatica', 1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materiaxcurso`
--

CREATE TABLE `materiaxcurso` (
  `ID_MAT` int(20) NOT NULL,
  `ID_CUR` varchar(3) NOT NULL,
  `YEAR` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `materiaxcurso`
--

INSERT INTO `materiaxcurso` (`ID_MAT`, `ID_CUR`, `YEAR`) VALUES
(1, '2B', 2019),
(2, '1B', 2019),
(5, '1A', 2019),
(9, '2B', 2019),
(9, '3A', 2019),
(10, '3A', 2019),
(11, '1B', 2019),
(12, '4A', 2019),
(13, '5B', 2019),
(14, '3A', 2019),
(17, '4A', 2019),
(18, '2B', 2019),
(19, '5A', 2019),
(20, '5B', 2019);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `DNI` int(10) NOT NULL,
  `APELLIDO` text,
  `NOMBRE` text,
  `PROVINCIA` text,
  `DIRECCION` varchar(25) DEFAULT NULL,
  `FECHA_NAC` varchar(11) DEFAULT NULL,
  `CATEGORIA` int(15) DEFAULT NULL,
  `F_INGRESO` varchar(11) DEFAULT NULL,
  `F_EGRESO` varchar(11) DEFAULT NULL,
  `ESTADO` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`DNI`, `APELLIDO`, `NOMBRE`, `PROVINCIA`, `DIRECCION`, `FECHA_NAC`, `CATEGORIA`, `F_INGRESO`, `F_EGRESO`, `ESTADO`) VALUES
(0, '', '', '', '', '', 3, '03/11/2019', '03/11/2019', 0),
(123456, 'Leyton Higueras', 'Lucas Fabian', 'Salta', 'Madrid 2533', '1996-11-10', 1, '25/09/2019', NULL, 1),
(15485695, 'Martinez', 'Marcos Antonio', 'Buenos Aires', 'San Juan 1548', '1980-06-11', 2, '11/09/2019', NULL, 1),
(25124894, 'Naveiro', 'Javier', 'Buenos Aires', 'San Martin 1548', '1983-11-12', 2, '03/11/2019', NULL, 1),
(35268745, 'Moreno', 'Daniel Emilio', 'Buenos Aires', 'San Clemente 1548', '1996-08-15', 3, '25/09/2019', '20/10/2019', 0),
(36592757, 'De Franceschi', 'Santiago', 'Buenos Aires', 'Laprida 555', '1991-10-12', 2, '25/09/2019', NULL, 1),
(38123321, 'Martin', 'Gonzalo ', 'Buenos Aires', 'San Martin 48', '1995-02-14', 2, '25/09/2019', '11/09/2019', 0),
(39415865, 'Echeverry', 'Alberto', 'CABA', 'Av. Santa Fe 4815', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415866, 'Alvarez', 'Jhon', 'CABA', 'Panamericana Km 35,5', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415867, 'Arango', 'Alejandra', 'CABA', 'Pte. Roca 4145', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415868, 'Arango', 'Jaider', 'CABA', 'Av. Olivos 4109', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415869, 'Arango', 'Marlen', 'CABA', 'Panamericana Km 36', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415870, 'Atehortua', 'Johana', 'CABA', 'Piedras 141', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415871, 'Atehortua', 'Nai', 'CABA', 'Paso 551', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415872, 'Ayala', 'Luz', 'CABA', 'Av. Cabildo 65', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415873, 'Barrientos', 'Jhon', 'CABA', 'Ayacucho 1050', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415874, 'Betancur', 'Mauro', 'CABA', 'Panamericana Km 36', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415875, 'Bustamante', 'Luis', 'CABA', 'Felipe Aranguren 154', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415876, 'Cardenas', 'Yulieth', 'CABA', 'Pi y Margal 750', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415877, 'Cardona', 'Daniel', 'CABA', 'San Martin', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415878, 'Castro', 'Jeisson', 'CABA', 'Diaz Velez 5044', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415879, 'Castro', 'Carlos', 'CABA', 'Cervio 3356', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415880, 'Echeverry', 'Hernado', 'CABA', 'Monroe 3555', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415881, 'Fernandez', 'Jose', 'CABA', 'General Urquiza 609', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415882, 'Garcia', 'Maria', 'CABA', 'Las Heras 267', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415883, 'Gaviria', 'Jorge', 'CABA', 'San Martin', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415884, 'Giraldo', 'Lina', 'CABA', 'Pilar 950 ', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415885, 'Gomez', 'Liliana', 'CABA', 'Combatientes de Malvinas ', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415886, 'Gomez', 'Miller', 'CABA', 'Pedro Calderon de la Barc', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415887, 'Gomez', 'Andres', 'CABA', 'Montes de Oca 4', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415888, 'Gonzalez', 'Isbelia', 'CABA', 'Gallo 1330 ', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415889, 'Grisales', 'Lina', 'CABA', 'Warnes 2630', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415890, 'Guzman', 'Johana', 'CABA', 'Brandsen 2570 ', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415891, 'Henao', 'Martha', 'CABA', 'Combatientes de Malvinas ', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415892, 'Hernandez', 'Marisol', 'CABA', 'Carrillo 375', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415893, 'Hincapie', 'Cristian', 'CABA', 'Pilar 950', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415894, 'Lopez', 'Juan', 'CABA', 'Carrillo 375', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415895, 'Lopera', 'Ruth', 'CABA', 'Gallo 1330', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415896, 'Lopera', 'Solina', 'CABA', 'Suarez 2215 ', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415897, 'Lopez', 'Lizeth', 'CABA', 'Pedro Calderon de la Barc', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415898, 'Lujan', 'Sandra', 'CABA', 'Montes de Oca 4', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415899, 'Madrigal', 'Esmeralda', 'CABA', 'Suarez 2215', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415900, 'Martinez', 'Carmen', 'CABA', 'Suarez 2215 ', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415901, 'Mendoza', 'Monica', 'CABA', 'Warnes 2630', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415902, 'Montoya', 'Luz', 'CABA', 'Sanchez de Bustamante 252', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415903, 'Mora', 'Rubiel', 'CABA', 'Don Pedro de Mendoza 1795', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415904, 'Mora', 'Yohan', 'CABA', 'Don Pedro de Mendoza 1715', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415905, 'Munera', 'Jhon', 'CABA', 'San Juan 2021', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415906, 'Ospina', 'Wilson', 'CABA', 'Brandsen 2570 ', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415907, 'Pareja', 'Fernando', 'CABA', 'Sanchez de Bustamante 252', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415908, 'Pemberthy', 'Diego', 'CABA', 'Suarez 2215', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415909, 'Perez', 'Yasmir', 'CABA', 'Diaz Velez 4821', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415910, 'Piedrahita', 'Genni', 'CABA', 'Segurola 1949', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415911, 'Porras', 'Yomaira', 'CABA', 'Osvaldo Cruz 2055', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415912, 'Porras', 'Marta', 'CABA', 'Esteban Bonorino 1729', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415913, 'Posada', 'Homero', 'CABA', 'Calle 9 Manzana 33', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415914, 'Posada', 'Orlando', 'CABA', 'Diaz Velez 4821', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415915, 'Restrepo', 'Jhon', 'CABA', 'Ana Maria Janer y Agustin', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415916, 'Restrepo', 'Olga', 'CABA', 'Humberto primo 470', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415917, 'Restrepo', 'Hernan', 'CABA', '2 de Abril 685', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415918, 'Rios', 'Gloria', 'CABA', 'Segurola 1949', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415919, 'Rojas', 'Ana', 'CABA', 'Curapaligle 1905', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415920, 'Rojo', 'Diana', 'CABA', 'Osvaldo Cruz 2055', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39415921, 'Rojo', 'Darwin', 'CABA', 'Fonrouge 4377', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415922, 'Rua', 'Ana', 'CABA', 'Diaz Velez 481', '01/03/2014', 3, '03/11/2019', NULL, 1),
(39415923, 'Sanchez', 'Marleny', 'CABA', '2 de Abril de 1982 N 685', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415924, 'Sanchez', 'Humberto', 'CABA', 'Humberto primo 470', '01/03/2013', 3, '03/11/2019', NULL, 1),
(39415925, 'Sepalveda', 'Juan', 'CABA', 'Ana Maria Janer y Agustin', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415926, 'Sierra', 'luz', 'CABA', 'Esteban Bonorino 1729', '01/03/2017', 3, '03/11/2019', NULL, 1),
(39415927, 'Soto', 'Juan', 'CABA', 'Curapaligre 1905', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415928, 'Soto', 'Margarita', 'CABA', 'Calle 9 Manzana 33', '01/03/2016', 3, '03/11/2019', NULL, 1),
(39415929, 'Soto', 'Ruth', 'CABA', 'Fonrouge 4377', '01/03/2015', 3, '03/11/2019', NULL, 1),
(39538264, 'Leyton Higueras', 'Lucas Fabian', 'Salta', 'Dean Funes 3255', '1996-03-31', 3, '25/09/2019', '20/10/2019', 0),
(39538267, 'Leyton Higueras', 'Lucas Fabian', 'Salta', 'Dean Funes 3255', '1996-01-31', 2, '25/09/2019', NULL, 1),
(50154856, 'Figueras', 'Fernando', 'Buenos Aires', 'Diaz Velez 4524', '1980-12-05', 2, '03/11/2019', NULL, 1),
(987654321, 'De Franceschi', 'Santiago Javier', 'Mendoza', 'Dean Funes 3255', '1995-10-11', 1, '25/09/2019', NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesores`
--

CREATE TABLE `profesores` (
  `ID_P` int(10) NOT NULL,
  `DNI_P` int(10) NOT NULL,
  `TITULO` text,
  `GRADO_ACADEMICO` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `profesores`
--

INSERT INTO `profesores` (`ID_P`, `DNI_P`, `TITULO`, `GRADO_ACADEMICO`) VALUES
(1, 36592757, 'TÃ©cnico en informÃ¡tica', 'Director'),
(1, 39538267, 'Supervisor clase 3', 'Director'),
(2, 38123321, 'Tecnico en analisis de sistemas', 'Maestro'),
(3, 15485695, 'TÃ©cnico en informÃ¡tica', 'Maestro'),
(4, 50154856, 'Tecnico en analisis de sistemas', 'Maestro'),
(5, 25124894, 'Lic en analisis de sistemas', 'Maestro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesorxmateria`
--

CREATE TABLE `profesorxmateria` (
  `DNI_PROF` int(9) NOT NULL,
  `ID_MAT` int(20) NOT NULL,
  `YEAR` int(4) NOT NULL,
  `FECHA_INICIO` varchar(11) NOT NULL,
  `FECHA_FIN` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `profesorxmateria`
--

INSERT INTO `profesorxmateria` (`DNI_PROF`, `ID_MAT`, `YEAR`, `FECHA_INICIO`, `FECHA_FIN`) VALUES
(15485695, 1, 2019, '11/09/2019', '20/10/2019'),
(15485695, 6, 2019, '21/09/2019', NULL),
(15485695, 12, 2019, '11/09/2019', NULL),
(15485695, 13, 2019, '25/09/2019', '20/10/2019'),
(15485695, 17, 2019, '20/10/2019', '03/11/2019'),
(15485695, 18, 2019, '03/11/2019', NULL),
(36592757, 5, 2019, '2019-08-02', '08/09/2019'),
(36592757, 7, 2019, '11/09/2019', NULL),
(36592757, 9, 2019, '04/09/2019', NULL),
(38123321, 3, 2019, '31/08/2019', NULL),
(38123321, 8, 2019, '03/09/2019', NULL),
(38123321, 10, 2019, '03/09/2019', NULL),
(39538267, 2, 2019, '2019-08-01', '08/09/2019'),
(39538267, 11, 2019, '11/09/2019', NULL),
(39538267, 14, 2019, '20/10/2019', NULL),
(50154856, 19, 2019, '03/11/2019', NULL),
(50154856, 20, 2019, '03/11/2019', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicacionxsecretario`
--

CREATE TABLE `publicacionxsecretario` (
  `ID_P` int(10) NOT NULL,
  `DNI_P` int(9) NOT NULL,
  `FECHA_P` varchar(30) DEFAULT NULL,
  `PUBLICACION` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `publicacionxsecretario`
--

INSERT INTO `publicacionxsecretario` (`ID_P`, `DNI_P`, `FECHA_P`, `PUBLICACION`) VALUES
(1, 123456, '22/09/2019', 'Se informa a los alumnos que el dia Viernes 27/09 no habra clases, debido a un corte electrico en el establecimiento'),
(2, 123456, '22/09/2019', 'A partir del dÃ­a 1/10, los Alumnos deberÃ¡n concurrir al establecimiento con el carnet escolar, de carÃ¡cter obligatorio.'),
(3, 123456, '23/09/2019', 'ART'),
(4, 123456, '25/09/2019', 'Prueba 1'),
(5, 987654321, '25/09/2019', 'Prueba 2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sancionxalumno`
--

CREATE TABLE `sancionxalumno` (
  `ID_SANCION` int(20) NOT NULL,
  `DNI_ALUMNO` int(20) NOT NULL,
  `DESCRIPCION` varchar(250) NOT NULL,
  `FECHA` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sancionxalumno`
--

INSERT INTO `sancionxalumno` (`ID_SANCION`, `DNI_ALUMNO`, `DESCRIPCION`, `FECHA`) VALUES
(1, 39538264, 'Mal Comportamiento', '29/08/2019'),
(2, 39538264, 'Ausencias Consecutivas ', '29/08/2019'),
(3, 39538264, 'Tendencia a Falta de respeto', '30/08/2019');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secretarios`
--

CREATE TABLE `secretarios` (
  `ID_S` int(10) NOT NULL,
  `DNI_S` int(10) NOT NULL,
  `TITULO` varchar(25) DEFAULT NULL,
  `CARGO` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `secretarios`
--

INSERT INTO `secretarios` (`ID_S`, `DNI_S`, `TITULO`, `CARGO`) VALUES
(3, 123456, 'TÃ©cnico en informÃ¡tica', 'Div SIAS'),
(4, 987654321, 'Supervisor clase 3', 'Super Intendente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesion_actual`
--

CREATE TABLE `sesion_actual` (
  `ID_SESION` int(2) DEFAULT NULL,
  `DNI_ACTUAL` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sesion_actual`
--

INSERT INTO `sesion_actual` (`ID_SESION`, `DNI_ACTUAL`) VALUES
(1, 39538267);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `ID_USUARIO` int(15) NOT NULL,
  `USUARIO` int(10) NOT NULL,
  `PASS` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`ID_USUARIO`, `USUARIO`, `PASS`) VALUES
(55, 39538267, '39538267'),
(56, 123456, '154853665'),
(85, 39415865, '39415865'),
(86, 39415866, '39415866'),
(87, 39415867, '39415867'),
(88, 39415868, '39415868'),
(89, 39415869, '39415869'),
(90, 39415870, '39415870'),
(91, 39415871, '39415871'),
(92, 39415872, '39415872'),
(93, 39415873, '39415873'),
(94, 39415874, '39415874'),
(95, 39415875, '39415875'),
(96, 39415876, '39415876'),
(97, 39415877, '39415877'),
(98, 39415878, '39415878'),
(99, 39415879, '39415879'),
(100, 39415880, '39415880'),
(101, 39415881, '39415881'),
(102, 39415882, '39415882'),
(103, 39415883, '39415883'),
(104, 39415884, '39415884'),
(105, 39415885, '39415885'),
(106, 39415886, '39415886'),
(107, 39415887, '39415887'),
(108, 39415888, '39415888'),
(109, 39415889, '39415889'),
(110, 39415890, '39415890'),
(111, 39415891, '39415891'),
(112, 39415892, '39415892'),
(113, 39415893, '39415893'),
(114, 39415894, '39415894'),
(115, 39415895, '39415895'),
(116, 39415896, '39415896'),
(117, 39415897, '39415897'),
(118, 39415898, '39415898'),
(119, 39415899, '39415899'),
(120, 39415900, '39415900'),
(121, 39415901, '39415901'),
(122, 39415902, '39415902'),
(123, 39415903, '39415903'),
(124, 39415904, '39415904'),
(125, 39415905, '39415905'),
(126, 39415906, '39415906'),
(127, 39415907, '39415907'),
(128, 39415908, '39415908'),
(129, 39415909, '39415909'),
(130, 39415910, '39415910'),
(131, 39415911, '39415911'),
(132, 39415912, '39415912'),
(133, 39415913, '39415913'),
(134, 39415914, '39415914'),
(135, 39415915, '39415915'),
(136, 39415916, '39415916'),
(137, 39415917, '39415917'),
(138, 39415918, '39415918'),
(139, 39415919, '39415919'),
(140, 39415920, '39415920'),
(141, 39415921, '39415921'),
(142, 39415922, '39415922'),
(143, 39415923, '39415923'),
(144, 39415924, '39415924'),
(145, 39415925, '39415925'),
(146, 39415926, '39415926'),
(147, 39415927, '39415927'),
(148, 39415928, '39415928'),
(149, 39415929, '39415929'),
(151, 50154856, '50154856'),
(152, 25124894, '25124894');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`ID_A`,`DNI_A`) USING BTREE,
  ADD KEY `ALU_CURSO` (`DNI_A`);

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`ID_CATEGORIA`);

--
-- Indices de la tabla `comentarioxalumno`
--
ALTER TABLE `comentarioxalumno`
  ADD PRIMARY KEY (`ID_COMENTARIO`,`DNI_ALUMNO`),
  ADD KEY `comentario_alumno` (`DNI_ALUMNO`);

--
-- Indices de la tabla `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`ID_CURSO`,`CURSO`,`ALUMNO_DNI`) USING BTREE,
  ADD KEY `ALUMNO_DNI` (`ALUMNO_DNI`),
  ADD KEY `ID_CURSO` (`ID_CURSO`),
  ADD KEY `CURSO` (`CURSO`);

--
-- Indices de la tabla `dias`
--
ALTER TABLE `dias`
  ADD PRIMARY KEY (`ID_DIA`) USING BTREE;

--
-- Indices de la tabla `estados`
--
ALTER TABLE `estados`
  ADD PRIMARY KEY (`ID_ESTADO`);

--
-- Indices de la tabla `horario`
--
ALTER TABLE `horario`
  ADD PRIMARY KEY (`ID_HORARIO`) USING BTREE;

--
-- Indices de la tabla `materia`
--
ALTER TABLE `materia`
  ADD PRIMARY KEY (`ID_MATERIA`) USING BTREE,
  ADD KEY `ID_DIAS` (`ID_DIAS`),
  ADD KEY `ID_HS` (`ID_HS`);

--
-- Indices de la tabla `materiaxcurso`
--
ALTER TABLE `materiaxcurso`
  ADD PRIMARY KEY (`ID_MAT`,`ID_CUR`) USING BTREE,
  ADD KEY `CURSO_MATERIAXCURSO` (`ID_CUR`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`DNI`,`ESTADO`) USING BTREE,
  ADD KEY `CATEGORIA` (`CATEGORIA`),
  ADD KEY `ESTADO` (`ESTADO`);

--
-- Indices de la tabla `profesores`
--
ALTER TABLE `profesores`
  ADD PRIMARY KEY (`ID_P`,`DNI_P`) USING BTREE,
  ADD KEY `PROF_PERSONA` (`DNI_P`);

--
-- Indices de la tabla `profesorxmateria`
--
ALTER TABLE `profesorxmateria`
  ADD PRIMARY KEY (`DNI_PROF`,`ID_MAT`) USING BTREE,
  ADD KEY `PROFESOR-CURSO` (`ID_MAT`);

--
-- Indices de la tabla `publicacionxsecretario`
--
ALTER TABLE `publicacionxsecretario`
  ADD PRIMARY KEY (`ID_P`,`DNI_P`),
  ADD KEY `P_SEC` (`DNI_P`);

--
-- Indices de la tabla `sancionxalumno`
--
ALTER TABLE `sancionxalumno`
  ADD PRIMARY KEY (`ID_SANCION`,`DNI_ALUMNO`) USING BTREE,
  ADD KEY `SANCION_ALUMNO` (`DNI_ALUMNO`);

--
-- Indices de la tabla `secretarios`
--
ALTER TABLE `secretarios`
  ADD PRIMARY KEY (`ID_S`,`DNI_S`) USING BTREE,
  ADD KEY `SEC_PERESO` (`DNI_S`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`ID_USUARIO`,`USUARIO`) USING BTREE,
  ADD KEY `USUARIO_PERSNA` (`USUARIO`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumno`
--
ALTER TABLE `alumno`
  MODIFY `ID_A` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `ID_CATEGORIA` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `comentarioxalumno`
--
ALTER TABLE `comentarioxalumno`
  MODIFY `ID_COMENTARIO` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `curso`
--
ALTER TABLE `curso`
  MODIFY `ID_CURSO` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT de la tabla `dias`
--
ALTER TABLE `dias`
  MODIFY `ID_DIA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `horario`
--
ALTER TABLE `horario`
  MODIFY `ID_HORARIO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `materia`
--
ALTER TABLE `materia`
  MODIFY `ID_MATERIA` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `materiaxcurso`
--
ALTER TABLE `materiaxcurso`
  MODIFY `ID_MAT` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `profesores`
--
ALTER TABLE `profesores`
  MODIFY `ID_P` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `profesorxmateria`
--
ALTER TABLE `profesorxmateria`
  MODIFY `DNI_PROF` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50154857;

--
-- AUTO_INCREMENT de la tabla `publicacionxsecretario`
--
ALTER TABLE `publicacionxsecretario`
  MODIFY `ID_P` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `sancionxalumno`
--
ALTER TABLE `sancionxalumno`
  MODIFY `ID_SANCION` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `secretarios`
--
ALTER TABLE `secretarios`
  MODIFY `ID_S` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `ID_USUARIO` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD CONSTRAINT `ALUM_PERSONA` FOREIGN KEY (`DNI_A`) REFERENCES `persona` (`DNI`);

--
-- Filtros para la tabla `comentarioxalumno`
--
ALTER TABLE `comentarioxalumno`
  ADD CONSTRAINT `comentario_alumno` FOREIGN KEY (`DNI_ALUMNO`) REFERENCES `alumno` (`DNI_A`);

--
-- Filtros para la tabla `materia`
--
ALTER TABLE `materia`
  ADD CONSTRAINT `diaxmateria` FOREIGN KEY (`ID_DIAS`) REFERENCES `dias` (`ID_DIA`),
  ADD CONSTRAINT `horarioxmateria` FOREIGN KEY (`ID_HS`) REFERENCES `horario` (`ID_HORARIO`);

--
-- Filtros para la tabla `materiaxcurso`
--
ALTER TABLE `materiaxcurso`
  ADD CONSTRAINT `CURSO_MATERIAXCURSO` FOREIGN KEY (`ID_CUR`) REFERENCES `curso` (`CURSO`),
  ADD CONSTRAINT `MATERIA_CURSO` FOREIGN KEY (`ID_MAT`) REFERENCES `materia` (`ID_MATERIA`);

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `CAT_PER` FOREIGN KEY (`CATEGORIA`) REFERENCES `categoria` (`ID_CATEGORIA`),
  ADD CONSTRAINT `Persona_estado` FOREIGN KEY (`ESTADO`) REFERENCES `estados` (`ID_ESTADO`);

--
-- Filtros para la tabla `profesores`
--
ALTER TABLE `profesores`
  ADD CONSTRAINT `PROF_PERSONA` FOREIGN KEY (`DNI_P`) REFERENCES `persona` (`DNI`);

--
-- Filtros para la tabla `profesorxmateria`
--
ALTER TABLE `profesorxmateria`
  ADD CONSTRAINT `MATERIA-PROFESOR` FOREIGN KEY (`DNI_PROF`) REFERENCES `profesores` (`DNI_P`),
  ADD CONSTRAINT `PROFESOR-CURSO` FOREIGN KEY (`ID_MAT`) REFERENCES `materia` (`ID_MATERIA`);

--
-- Filtros para la tabla `publicacionxsecretario`
--
ALTER TABLE `publicacionxsecretario`
  ADD CONSTRAINT `P_SEC` FOREIGN KEY (`DNI_P`) REFERENCES `secretarios` (`DNI_S`);

--
-- Filtros para la tabla `sancionxalumno`
--
ALTER TABLE `sancionxalumno`
  ADD CONSTRAINT `SANCION_ALUMNO` FOREIGN KEY (`DNI_ALUMNO`) REFERENCES `alumno` (`DNI_A`);

--
-- Filtros para la tabla `secretarios`
--
ALTER TABLE `secretarios`
  ADD CONSTRAINT `SEC_PERESO` FOREIGN KEY (`DNI_S`) REFERENCES `persona` (`DNI`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `USUARIO_PERSNA` FOREIGN KEY (`USUARIO`) REFERENCES `persona` (`DNI`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
