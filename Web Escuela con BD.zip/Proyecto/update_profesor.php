<?php
include("conexion.php");
extract($_GET);
$apellido=$_POST['APELLIDO'];
$nombre=$_POST['NOMBRE'];
$provincia=$_POST['PROVINCIA'];
$direccion=$_POST['DIRECCION'];
$fechanac=$_POST['FECHANAC'];
$titulo=$_POST['TITULO'];
$grado=$_POST['GRADO'];

//update registro
$sqlprofesor = "UPDATE profesores SET TITULO = '$titulo', GRADO_ACADEMICO= '$grado' WHERE DNI_P ='$id'";

if($conn -> query($sqlprofesor) === TRUE) {

		$sqlpersona = "UPDATE persona SET APELLIDO= '$apellido', NOMBRE= '$nombre', PROVINCIA = '$provincia', DIRECCION='$direccion' , FECHA_NAC='$fechanac' WHERE DNI='$id'";
		if($conn -> query($sqlpersona) === TRUE) {
			echo '<script>alert("ACTUALIZACION  REALIZADA")</script> ';
			echo "<script>location.href='Buscar.php'</script>";
		}
}

else{echo '<script>alert("NO SE PUDO REALIZAR LA ACTUALIZACION")</script> ';}

?>