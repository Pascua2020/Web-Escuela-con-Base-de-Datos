<?php
require_once("conexion.php");
//	include (conexion.php);

$usuario = $_POST['USUARIO'];	
$pass = $_POST['PASS'];		

$sqlusuario = "SELECT * from usuarios WHERE USUARIO = $usuario";

$result = $conn->query($sqlusuario);

if($result->num_rows > 0)
	{
		$row = $result ->fetch_assoc();
		if($pass == $row["PASS"])
		{
			$sqlcategoria = "SELECT * from persona WHERE DNI = $usuario";
			$resultcategoria = $conn->query($sqlcategoria);
			if($resultcategoria->num_rows > 0){
				$rowcategoria = $resultcategoria ->fetch_assoc();
				$categoria = $rowcategoria["CATEGORIA"];
			}
			echo '<script>alert("TE DAMOS LA BIENVENIDA")</script> ';
			// Actualizamos sesion actual

			$sqlsesion = "UPDATE sesion_actual SET DNI_ACTUAL = '$usuario' WHERE ID_SESION ='1'";
			if($conn -> query($sqlsesion) === TRUE) {
				}else{
					echo '<script>alert("Error de SESION")</script> ';
			}

			//Redireccionar	

			if ($categoria == 3) {
			    echo "<script>location.href='publicaciones.php'</script>";
			} elseif ($categoria == 2) {
			    echo "<script>location.href='PropiedadesProfesor.html'</script>";
			} elseif ($categoria == 1) {
			    echo "<script>location.href='PropiedadesSecretario.html'</script>";
			}

		}
		else{
			echo '<script>alert("usuario o contrasena incorrecta")</script> ';
			echo "<script>location.href='login.html'</script>";
		}
	}
else
	{
		echo '<script>alert("Usuario inexistente")</script> ';
		echo "<script>location.href='login.html'</script>";
	}


$conn->close();

?>