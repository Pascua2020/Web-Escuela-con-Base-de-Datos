<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Nueva Publicacion</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Registrar una Nueva Publicacion</h1>
			<h1><small></small></h1>
			<br></br>
		</div>
	</header>

	<div class="conteiner" align="center">
		<div class="col-md-3" align="left">
		</div>
			
		<div class="col-md-6" align="center">
			<br></br>
			<form method = POST action="enviar_publicacion.php?">

				<div class="container" align="left">
					<br></br>
					<label for="uname"><b>Escribir el texto a publicar</b></label>
					<br></br>

					<div class="form-group">
  						<label for="comment">Texto:</label>
  						<textarea class="form-control" rows="5" name="TEXTO"></textarea>
					</div>
			
					<br></br>
					<button type="submit" class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block">Guardar</button>
					<br></br>
				</div>	
							  
			</form>			
		</div>

		<div class="col-md-3">
		</div>
	</div>

	<div class="conteiner" align="left">
		<div class="col-md-2" align="left">
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" onclick=" location.href='PropiedadesSecretario.html' ">Volver</button>
		</div>
		<br></br>
	</div>

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>