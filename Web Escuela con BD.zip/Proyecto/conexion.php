<?php

$host="localhost";
$user="root";
$pass= "";
$db="escuela";

$conn= new mysqli($host, $user, $pass, $db);

	if($conn->connect_error) {
		die ("No se puede conectar a la base".$conn->connect_error);
	}



?>