<?php

	require("conexion.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Profesores</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Visualizar Profesores</h1>
			<h1><small>Seleccionar un profesor</small></h1>
			<br></br>
		</div>
	</header>

	<br></br>

	<div class="row" id="ppt">
	<div class="col-md-1" align="left">
			
	</div>
			
		<div class="col-md-10" align="left">

			<?php

				$profesores=("SELECT * FROM persona, profesores WHERE persona.DNI = profesores.DNI_P  AND persona.CATEGORIA = 2 AND persona.ESTADO = '1'");	
				$query=mysqli_query($conn,$profesores);

					echo "<table border='1'; class='table table-hover';>";
					echo "<tr class='warning'>";
						echo "<th>DNI</th>";
						echo "<th>Apellido</th>";
						echo "<th>Nombre</th>";
						echo "<th>Titulo</th>";
						echo "<th>Grado Academico</th>";
						echo "<th>Materias</th>";
						echo "<th>Agregar Materia</th>";
					echo "</tr>";				

					while($arreglo=mysqli_fetch_array($query)){
						
						  		echo "<tr class='success'>";
						    	echo "<td>$arreglo[0]</td>";
						    	echo "<td>$arreglo[1]</td>";
						    	echo "<td>$arreglo[2]</td>";
						    	echo "<td>$arreglo[12]</td>";
						    	echo "<td>$arreglo[13]</td>";
						    	echo "<td><a href='ver_materias_profesor.php?dni=$arreglo[0]'><img src='img/lupa2.png' class='img-rounded'></td>"; 
						    	echo "<td><a href='materias_disponibles.php?dni=$arreglo[0]'><img src='img/mas.png' class='img-rounded'></td>";
						
							echo "</tr>";
							}

						echo "</table>";
			
			?>
		</div>
		<div class="col-md-1" align="left">
		</div>
	</div>
	<br></br>
	<div class="conteiner" align="left">
		<div class="col-md-2" align="left">
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" onclick=" location.href='PropiedadesSecretario.html ?>' ">Volver</button>
		</div>
		<br></br>
	</div>

	

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>