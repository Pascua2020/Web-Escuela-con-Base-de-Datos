<?php
extract($_GET);
require_once("conexion.php");

$comentario=$_POST['TEXTO'];
$fecha=date("d/m/Y");


		$sqlcomentario = "INSERT INTO comentarioxalumno (DNI_ALUMNO, DESCRIPCION, FECHA) VALUES ('$dni', '$comentario', '$fecha')";

		if ($conn->query($sqlcomentario) === TRUE) {

				echo '<script>alert("Comentario registrado con exito")</script> ';

			} else { 

			echo "Error: ". $sqlcomentario . "<br>". $conn->error;

		}


$conn->close();
echo "<script>location.href='visualizar_alumnosP.php'</script>";

?>