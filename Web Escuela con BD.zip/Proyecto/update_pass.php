<?php
require_once("conexion.php");
//	include (conexion.php);

$usuario = $_POST['USUARIO'];	
$pass = $_POST['PASS'];		
$passw = $_POST['PASSW'];		


$sqlusuario = "SELECT * from usuarios WHERE USUARIO = $usuario";

$result = $conn->query($sqlusuario);

if($result->num_rows > 0)
	{
		if($pass == $passw)
		{
			$sql = "UPDATE usuarios SET PASS = '$pass' WHERE USUARIO ='$usuario'";
			if($conn -> query($sql) === TRUE) {
					echo '<script>alert("Se ha Cambiado su Contraseña")</script> ';
					echo "<script>location.href='Login.html'</script>";
				}else{
					echo '<script>alert("Error al realizar la Actualizacion")</script> ';
					echo "<script>location.href='cambiar_pass.html'</script>";
			}

		}
		else{
			echo '<script>alert("Las contraseñas no coinciden")</script> ';
			echo "<script>location.href='cambiar_pass.html'</script>";
		}
	}
else
	{
		echo '<script>alert("Usuario inexistente")</script> ';
		echo "<script>location.href='cambiar_pass.html'</script>";
	}


$conn->close();

?>