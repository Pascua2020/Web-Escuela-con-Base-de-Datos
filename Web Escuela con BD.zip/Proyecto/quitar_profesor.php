<?php
extract($_GET);
include("conexion.php");

$sql="SELECT * FROM materia WHERE ID_MATERIA=$id";

$ressql=mysqli_query($conn,$sql);
	while ($row=mysqli_fetch_row ($ressql)){
	    	$materia=$row[1];
			$horario=$row[2];
			$dia=$row[3];
	}

$fecha=date("d/m/Y");
	
	//update registro

$sqlprof = "UPDATE profesorxmateria SET FECHA_FIN = '$fecha' WHERE ID_MAT ='$id'";

if($conn -> query($sqlprof) === TRUE) {
		echo '<script>alert("Profesor Desvinculado")</script> ';
	}
	else{
		echo '<script>alert("NO SE PUDO QUITAR PROFESOR")</script> ';
}

	//crear una nueva materia disponible

$sqlmateria = "INSERT INTO materia (NOMBRE, ID_HS, ID_DIAS) VALUES ('$materia', '$horario', '$dia')";

if ($conn->query($sqlmateria) === TRUE) {

	echo '<script>alert("Materia Agregada")</script> ';
	echo "<script>location.href='editar_materia.php'</script>";
} else { 
	echo "Error: ". $sqlmateria . "<br>". $conn->error;
}

$conn->close();
?>