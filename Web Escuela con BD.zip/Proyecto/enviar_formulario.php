<?php
require_once("conexion.php");
//	include (conexion.php);

$apellido=$_POST['APELLIDO'];

$nombre=$_POST['NOMBRE'];

$dni=$_POST['DNI'];

$provincia=$_POST['PROVINCIA'];

$direccion=$_POST['DIRECCION'];

$fechanac=$_POST['FECHANAC'];

$categoria=$_POST['CATEGORIA'];

$fecha=date("d/m/Y");

$estado= '1' ;

//CARGAR FORMULARIO

$sqlformulario = "INSERT INTO persona (DNI, APELLIDO, NOMBRE, PROVINCIA, DIRECCION, FECHA_NAC, CATEGORIA, F_INGRESO, ESTADO) VALUES ('$dni', '$apellido', '$nombre', '$provincia', '$direccion', '$fechanac', '$categoria', '$fecha','$estado')";

if ($conn->query($sqlformulario) === TRUE) {

	//CARGAR FORMULARIO PARTE 2

	if ($categoria == 1) {

	$titulo=$_POST['TITULO'];
	$cargo=$_POST['CARGO'];
    $sqlformulario2 = "INSERT INTO secretarios (DNI_S, TITULO, CARGO) VALUES ('$dni', '$titulo', '$cargo')";

    	if ($conn->query($sqlformulario2) === TRUE) {
			echo '<script>alert("Registro Completado")</script> ';
			} else { 
			echo "Error: ". $sqlformulario2 . "<br>". $conn->error;
		}

	} 
	elseif ($categoria == 2) {

	$titulo=$_POST['TITULO'];
	$grado=$_POST['GRADO'];
    $sqlformulario2 = "INSERT INTO profesores (DNI_P, TITULO, GRADO_ACADEMICO) VALUES ('$dni', '$titulo', '$grado')";

    	if ($conn->query($sqlformulario2) === TRUE) {
			echo '<script>alert("Registro Completado")</script> ';
			} else { 
			echo "Error: ". $sqlformulario2 . "<br>". $conn->error;
		}

	}
	elseif ($categoria == 3) {
	$legajo=$_POST['LEGAJO'];
	$curso=$_POST['CURSO'];
    $sqlformulario2 = "INSERT INTO alumno (DNI_A, LEGAJO) VALUES ('$dni', '$legajo')";

		if ($conn->query($sqlformulario2) === TRUE) {
			echo '<script>alert("Registro Completado")</script> ';
			} else { 
			echo "Error: ". $sqlformulario2 . "<br>". $conn->error;
		}
		$sqlformulario3 = "INSERT INTO curso (CURSO, ALUMNO_DNI) VALUES ('$curso', '$dni')";

		if ($conn->query($sqlformulario3) === TRUE) {
			} else { 
			echo "Error: ". $sqlformulario3 . "<br>". $conn->error;
		}
	
	 
	
	} 
	

} else {
	echo "Error: ". $sqlformulario . "<br>". $conn->error;
}

//GENERAR USUARIO

$sqlusuario = "INSERT INTO usuarios (USUARIO, PASS) VALUES ('$dni', '$dni')";

if ($conn->query($sqlusuario) === TRUE) {

	echo '<script>alert("Usuario Generado Correctamente")</script> ';

	} else { 
	echo "Error: ". $sqlusuario . "<br>". $conn->error;
}

$conn->close();
echo "<script>location.href='PropiedadesSecretario.html'</script>";

?>