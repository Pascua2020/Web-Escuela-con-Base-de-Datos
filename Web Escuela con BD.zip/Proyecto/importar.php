<?php
	# conectare la base de datos
    include("conexion.php");
	
	$alumnos = fopen ("alumnos.csv" , "r" );//leo el archivo que contiene los datos del producto
while (($datos =fgetcsv($alumnos,500,";")) !== FALSE )//Leo linea por linea del archivo hasta un maximo de 1000 caracteres por linea leida usando coma(;) como delimitador
{
 $linea[]=array('DNI'=>$datos[0],'APELLIDO'=>$datos[1],'NOMBRE'=>$datos[2],'PROVINCIA'=>$datos[3],'DIRECCION'=>$datos[4],'FECHA_NAC'=>$datos[5],'LEGAJO'=>$datos[6],'CURSO'=>$datos[7]);//Arreglo Bidimensional para guardar los datos de cada linea leida del archivo
}
fclose ($alumnos);//Cierra el archivo

	$ingresado=0;//Variable que almacenara los insert exitosos
	$error=0;//Variable que almacenara los errores en almacenamiento
	$duplicado=0;//Variable que almacenara los registros duplicados
    foreach($linea as $indice=>$value) //Iteracion el array para extraer cada uno de los valores almacenados en cada items
	{
	$dni=$value["DNI"];//Codigo del producto
	$apellido=$value["APELLIDO"];//descripcion del producto
	$nombre=$value["NOMBRE"];//fabricante del producto
	$provincia=$value["PROVINCIA"];//precio del producto
	$direccion=$value["DIRECCION"];//precio del producto
	$nac=$value["FECHA_NAC"];//precio del producto
	$legajo=$value["LEGAJO"];//precio del producto
	$curso=$value["CURSO"];//precio del producto
	
	$sql=mysqli_query($conn,"select * from persona where DNI='$dni'");//Consulta a la tabla productos
	$num=mysqli_num_rows($sql);//Cuenta el numero de registros devueltos por la consulta
	if ($num==0)//Si es == 0 inserto
	{
	if ($insertp=mysqli_query($conn,"insert into persona (DNI, APELLIDO, NOMBRE, PROVINCIA, DIRECCION, FECHA_NAC, CATEGORIA) values('$dni','$apellido','$nombre','$provincia','$direccion','$nac','3')"))
	{
		if ($insertu=mysqli_query($conn,"insert into usuarios (USUARIO, PASS) values('$dni','$dni')"))
		{
			if ($inserta=mysqli_query($conn,"insert into alumno (DNI_A, LEGAJO) values('$dni','$legajo')"))
			{
				if ($inserta=mysqli_query($conn,"insert into curso (CURSO, ALUMNO_DNI) values('$curso','$dni')"))
				{
				echo $msj='<font color=green>Alumno <b>'.$apellido.'</b> Guardado</font><br/>';
				$ingresado+=1;
				}
			}
		}
	}//fin del if que comprueba que se guarden los datos
	else//sino ingresa el alumno
	{
	echo $msj='<font color=red>Alumno <b>'.$apellido.' </b> NO Guardado '.mysqli_error().'</font><br/>';
	$error+=1;
	}
	}//fin de if que comprueba que no haya en registro duplicado
	else
	{
	$duplicado+=1;
	echo $duplicate='<font color=red>El Alumno <b>'.$apellido.'</b> Esta duplicado<br></font>';
	}
	}
	echo "<font color=green>".number_format($ingresado,2)." Productos Almacenados con exito<br/>";
	echo "<font color=red>".number_format($duplicado,2)." Productos Duplicados<br/>";
	echo "<font color=red>".number_format($error,2)." Errores de almacenamiento<br/>";
	?>