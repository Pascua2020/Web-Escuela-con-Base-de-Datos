<?php
	require("conexion.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Personal</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Visualizar Personal</h1>
			<h1><small></small></h1>
			<br></br>
		</div>
	</header>

	<div class="row">
		<div class="col-md-1" align="center">
	</div>

<div class="col-md-10" align="center">
			
	<div class="container">
		<br>
		<ul class="nav nav-tabs" role="tablist">
				<li class="nav-item">
				 	<a class="nav-link active" data-toggle="tab" href="#home">Alumnos</a>
				</li>
				<li class="nav-item">
					 <a class="nav-link" data-toggle="tab" href="#menu1">Profesores</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link" data-toggle="tab" href="#menu2">Secretarios</a>
			 </li>
		</ul>

  <!-- Tab panes -->
  	<div class="tab-content">
    <div id="home" class="container tab-pane active"><br>
      <h3></h3>
      <?php

				$alumnos=("SELECT * FROM persona, alumno WHERE persona.DNI = alumno.DNI_A  AND persona.CATEGORIA = '3' AND persona.ESTADO = '1'");	
				$query=mysqli_query($conn,$alumnos);

					echo "<table border='1'; class='table table-hover';>";
					echo "<tr class='warning'>";
						echo "<th>DNI</th>";
						echo "<th>Apellido</th>";
						echo "<th>Nombre</th>";
						echo "<th>Legajo</th>";
						echo "<th>Provincia</th>";
						echo "<th>Direccion</th>";
						echo "<th>Nacimiento</th>";
						echo "<th>Fecha de Ingreso</th>";
						echo "<th>Editar</th>";
						echo "<th>Borrar</th>";
					echo "</tr>";				

					while($arreglo=mysqli_fetch_array($query)){
						
						  		echo "<tr class='success'>";
						    	echo "<td>$arreglo[0]</td>";
						    	echo "<td>$arreglo[1]</td>";
						    	echo "<td>$arreglo[2]</td>";
						    	echo "<td>$arreglo[12]</td>";
						    	echo "<td>$arreglo[3]</td>";
						    	echo "<td>$arreglo[4]</td>";
						    	echo "<td>$arreglo[5]</td>";
						    	echo "<td>$arreglo[7]</td>";
						    	echo "<td><a href='editar_alumno.php?id=$arreglo[0]'><img src='img/edit.png' class='img-rounded'></td>";
						    	echo "<td><a href='delete_persona.php?id=$arreglo[0]'><img src='img/borrar.png' class='img-rounded'/></a></td>";
						    	
				
							echo "</tr>";
							}

						echo "</table>";
			
			?>
    </div>
    <div id="menu1" class="container tab-pane fade"><br>
    	<h3></h3>
      <?php
      $profesores=("SELECT * FROM persona, profesores WHERE persona.DNI = profesores.DNI_P  AND persona.CATEGORIA = '2' AND persona.ESTADO = '1'");	
				$query=mysqli_query($conn,$profesores);

					echo "<table border='1'; class='table table-hover';>";
					echo "<tr class='warning'>";
						echo "<th>DNI</th>";
						echo "<th>Apellido</th>";
						echo "<th>Nombre</th>";
						echo "<th>Titulo</th>";
						echo "<th>Provincia</th>";
						echo "<th>Direccion</th>";
						echo "<th>Nacimiento</th>";
						echo "<th>Fecha de Ingreso</th>";
						echo "<th>Editar</th>";
						echo "<th>Borrar</th>";
					echo "</tr>";				

					while($arreglo=mysqli_fetch_array($query)){
						
						  		echo "<tr class='success'>";
						    	echo "<td>$arreglo[0]</td>";
						    	echo "<td>$arreglo[1]</td>";
						    	echo "<td>$arreglo[2]</td>";
						    	echo "<td>$arreglo[12]</td>";
						    	echo "<td>$arreglo[3]</td>";
						    	echo "<td>$arreglo[4]</td>";
						    	echo "<td>$arreglo[5]</td>";
						    	echo "<td>$arreglo[7]</td>";
						    	echo "<td><a href='editar_profesor.php?id=$arreglo[0]'><img src='img/edit.png' class='img-rounded'></td>";

						    	echo "<td><a href='delete_persona.php?id=$arreglo[0]'><img src='img/borrar.png' class='img-rounded'/></a></td>";
						
				echo "</tr>";
				}

			echo "</table>";
			
			?>

    </div>
    <div id="menu2" class="container tab-pane fade"><br>
      <h3></h3>
      <?php
      $profesores=("SELECT * FROM persona, secretarios WHERE persona.DNI = secretarios.DNI_S  AND persona.CATEGORIA = '1' AND persona.ESTADO = '1'");	
				$query=mysqli_query($conn,$profesores);

					echo "<table border='1'; class='table table-hover';>";
					echo "<tr class='warning'>";
						echo "<th>DNI</th>";
						echo "<th>Apellido</th>";
						echo "<th>Nombre</th>";
						echo "<th>Cargo</th>";
						echo "<th>Provincia</th>";
						echo "<th>Direccion</th>";
						echo "<th>Nacimiento</th>";
						echo "<th>Fecha de Ingreso</th>";
						echo "<th>Editar</th>";
						echo "<th>Borrar</th>";
					echo "</tr>";				

					while($arreglo=mysqli_fetch_array($query)){
						
						  		echo "<tr class='success'>";
						    	echo "<td>$arreglo[0]</td>";
						    	echo "<td>$arreglo[1]</td>";
						    	echo "<td>$arreglo[2]</td>";
						    	echo "<td>$arreglo[12]</td>";
						    	echo "<td>$arreglo[3]</td>";
						    	echo "<td>$arreglo[4]</td>";
						    	echo "<td>$arreglo[5]</td>";
						    	echo "<td>$arreglo[7]</td>";
						    	echo "<td><a href='editar_secretario.php?id=$arreglo[0]'><img src='img/edit.png' class='img-rounded'></td>";

						    	echo "<td><a href='delete_persona.php?id=$arreglo[0]'><img src='img/borrar.png' class='img-rounded'/></a></td>";
						
				echo "</tr>";
				}

			echo "</table>";
			
			?>

    </div>
  </div>
  		<br></br>
		<br></br>
</div>

		</div>
			<div class="col-md-1" align="center">

		</div>

	</div>

	<div class="conteiner" align="left">
		<div class="col-md-2" align="left">
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" onclick=" location.href='PropiedadesSecretario.html' ">Volver</button>
		</div>
		<br></br>
	</div>
	<br></br>



	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>