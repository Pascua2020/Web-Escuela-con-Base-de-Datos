<?php
require_once("conexion.php");
//	include (conexion.php);

$usuario = $_POST['USUARIO'];	
	
$sqlusuario = "SELECT * from usuarios WHERE USUARIO = $usuario";

$result = $conn->query($sqlusuario);

if($result->num_rows > 0)
	{
			$sql = "UPDATE usuarios SET PASS = '$usuario' WHERE USUARIO ='$usuario'";
			if($conn -> query($sql) === TRUE) {
					echo '<script>alert("Se ha Cambiado Contraseña")</script> ';
					echo "<script>location.href='PropiedadesSecretario.html'</script>";
				}else{
					echo '<script>alert("Error al Restablescer Contraseña")</script> ';
					echo "<script>location.href='desbloquear_usuario.html'</script>";
			}

	}
	else{
		echo '<script>alert("Usuario Inexistente")</script> ';
		echo "<script>location.href='desbloquear_usuario.html'</script>";
	}


$conn->close();

?>