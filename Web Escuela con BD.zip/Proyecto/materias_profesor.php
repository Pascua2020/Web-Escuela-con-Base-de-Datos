<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Materias</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Visualizar Materias y Profesores</h1>
			<h1><small>Seleccione Materia a Asignar</small></h1>
			<br></br>
		</div>
	</header>

	<br></br>

	<div class="row" id="ppt">
	<div class="col-md-1" align="left">
			
	</div>
			
		<div class="col-md-10" align="left">

			<?php
				require("conexion.php");

		
				$c=$_POST['CURSO'];

				$materias=("SELECT * FROM materia, profesorxmateria, profesores, persona WHERE materia.ID_MATERIA = profesorxmateria.ID_MAT AND profesorxmateria.DNI_PROF = profesores.DNI_P AND profesores.DNI_P = persona.DNI");	

				$query=mysqli_query($conn,$materias);

					echo "<table border='1'; class='table table-hover';>";
					echo "<tr class='warning'>";
						echo "<th>DNI</th>";
						echo "<th>Apellido</th>";
						echo "<th>Nombre</th>";
						echo "<th>Materia</th>";
						echo "<th>Año</th>";
						echo "<th>Seleccionar</th>";
					echo "</tr>";	


				while($arreglo=mysqli_fetch_array($query)){
		
				
						echo "<tr class='success'>";
						  	echo "<td>$arreglo[13]</td>";
						  	echo "<td>$arreglo[14]</td>";
						  	echo "<td>$arreglo[15]</td>";
						  	echo "<td>$arreglo[1]</td>";
						  	echo "<td>$arreglo[6]</td>";
						  	echo "<td><a href='vincular_mc.php?c=$c&m=$arreglo[0]'><img src='img/seleccionar.png' class='img-rounded'></td>";
						
						echo "</tr>";
							
				}

				echo "</table>";
			
			?>
		</div>
		<div class="col-md-1" align="left">
		</div>
	</div>
	<br></br>
	<div class="conteiner" align="left">
		<div class="col-md-2" align="left">
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" onclick=" location.href='Semestre.html ?>' ">Volver</button>
		</div>
		<br></br>
	</div>

	

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>