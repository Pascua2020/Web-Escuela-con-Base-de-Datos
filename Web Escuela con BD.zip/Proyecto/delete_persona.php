<?php
		extract($_GET);
		require("conexion.php");

		$sql="SELECT * FROM persona WHERE DNI=$id";
		$result = $conn -> query($sql);
		$fecha=date("d/m/Y");
		$estado='0';

		if(mysqli_num_rows($result) > 0)

			{

				$sqlegreso = "UPDATE persona SET F_EGRESO = '$fecha',ESTADO = '$estado' WHERE DNI ='$id'";

					if($conn -> query($sqlegreso) === TRUE) {
						$borrar= "DELETE FROM usuarios where USUARIO ='$id' ";
						$result = $conn -> query($borrar);
						echo '<script>alert("EGRESO REALIZADO CON EXITO")</script> ';
						echo "<script>location.href='Buscar.php'</script>";
					}
						else{
						echo '<script>alert("NO SE ACTUALIZO FECHA DE EGRESO")</script> ';
					}
						
			}
			else 
			{
					
				echo '<script>alert("REGISTRO NO ENCONTRADO")</script> ';
				echo "<script>location.href='Buscar.php'</script>";
			
			}

?>
