<?php

	require("conexion.php");
	$curso = $_POST['CURSO'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Alumnos</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Visualizar Alumnos</h1>
			<h1><small><?php echo $curso?></small></h1>
			<br></br>
		</div>
	</header>

	<br></br>

	<div class="row" id="ppt">
	<div class="col-md-1" align="left">
			
	</div>
			
		<div class="col-md-10" align="left">

			<?php

				$alumnos=("SELECT * FROM curso WHERE CURSO = '$curso'");	
				$queryalumnos=mysqli_query($conn,$alumnos);

					echo "<table border='1'; class='table table-hover';>";
					echo "<tr class='warning'>";
						echo "<th>DNI</th>";
						echo "<th>Apellido</th>";
						echo "<th>Nombre</th>";
						echo "<th>Provincia</th>";
						echo "<th>Direccion</th>";
						echo "<th>Nacimiento</th>";
						echo "<th>Ver Sanciones</th>";
						echo "<th>Registrar Comentario</th>";
						echo "<th>Ver Comportamiento</th>";
					echo "</tr>";				

					while($arregloalumnos=mysqli_fetch_array($queryalumnos)){
						$dni = $arregloalumnos[2];

						$sql=("SELECT * FROM persona WHERE DNI = '$dni' AND ESTADO = '1'");
	
						$query=mysqli_query($conn,$sql);

						while($arreglo=mysqli_fetch_array($query)){
						  		echo "<tr class='success'>";
						    	echo "<td>$arreglo[0]</td>";
						    	echo "<td>$arreglo[1]</td>";
						    	echo "<td>$arreglo[2]</td>";
						    	echo "<td>$arreglo[3]</td>";
						    	echo "<td>$arreglo[4]</td>";
						    	echo "<td>$arreglo[5]</td>";
						    	echo "<td><a href='visualizar_sancionesP.php?id=$arreglo[0]'><img src='img/lupa2.png' class='img-rounded'></td>";

								echo "<td><a href='registrar_comentario.php?id=$arreglo[0]'><img src='img/globo.png' class='center'/></a></td>";	

								echo "<td><a href='visualizar_comentariosP.php?id=$arreglo[0]'><img src='img/comportamiento.jpg' class='img-rounded'/></a></td>";	

						
							echo "</tr>";
							}

						
					}
					echo "</table>";
					
			?>
			<br></br>


		</div>
		<div class="col-md-1" align="left">
		</div>
	</div>
	<br></br>
	<div class="conteiner" align="left">
		<div class="col-md-2" align="left">
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" onclick=" location.href='visualizar_alumnosP.php ?>' ">Volver</button>
		</div>
		<br></br>
	</div>

	

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>