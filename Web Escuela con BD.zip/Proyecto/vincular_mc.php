<?php
require_once("conexion.php");

extract($_GET);
$year=date("Y");

$sqlvincular = "INSERT INTO materiaxcurso (ID_MAT, ID_CUR, YEAR) VALUES ('$m', '$c', '$year')";

if ($conn->query($sqlvincular) === TRUE) {

echo '<script>alert("Materia asignada correctamente")</script> ';

	} else { 
	echo "Error: ". $sqlvincular . "<br>". $conn->error;
}

$conn->close();
echo "<script>location.href='PropiedadesSecretario.html'</script>";

?>