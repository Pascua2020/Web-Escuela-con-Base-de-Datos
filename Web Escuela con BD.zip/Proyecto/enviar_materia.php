<?php
require_once("conexion.php");
//	include (conexion.php);

$materia=$_POST['MATERIA'];
		
$dia=$_POST['DIA'];

$horario=$_POST['HORARIO'];

$sqlmateria = "INSERT INTO materia (NOMBRE, ID_HS, ID_DIAS) VALUES ('$materia', '$horario', '$dia')";

if ($conn->query($sqlmateria) === TRUE) {

	echo '<script>alert("Materia Agregada")</script> ';
	echo "<script>location.href='PropiedadesSecretario.html'</script>";

} else { 
	echo "Error: ". $sqlmateria . "<br>". $conn->error;
}

$conn->close();

?>
