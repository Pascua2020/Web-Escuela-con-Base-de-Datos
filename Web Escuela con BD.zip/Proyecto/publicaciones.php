<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Publicaciones</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Publicaciones de interes</h1>
			<h1><small></small></h1>
			<br></br>
		</div>
	</header>

	<?php
	require("conexion.php");

		$publicaciones=("SELECT * FROM publicacionxsecretario,persona WHERE publicacionxsecretario.DNI_P = persona.DNI");	
		$querypublicaciones=mysqli_query($conn,$publicaciones);				

		while($arreglo=mysqli_fetch_array($querypublicaciones)){
			
	?>
			<div class="container mt-3">
 			<br></br>
	 		 	<div class="media border p-3">
	  		 	 	<div class="media-body">
		  		  	  	<h3><?php echo "$arreglo[5]",", ","$arreglo[6]";?><h3>
		  		 	   	<h4><small><i>Fecha de Publicacion: <?php echo "$arreglo[2]";?></i></small></h4>
		  		   	 	<p><?php echo "$arreglo[3]";?></p>      
	 		   		</div>
				</div>
			</div>
	<?php
		}
	?>

	<br></br>
	
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>