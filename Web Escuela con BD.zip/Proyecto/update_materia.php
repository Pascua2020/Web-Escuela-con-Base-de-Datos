<?php
extract($_GET);
include("conexion.php");

$materia=$_POST['MATERIA'];	
$dia=$_POST['DIA'];
$horario=$_POST['HORARIO'];
	
//update registro
$sqlmateria = "UPDATE materia SET NOMBRE = '$materia', ID_HS = '$horario', ID_DIAS = '$dia' WHERE ID_MATERIA ='$id'";

if($conn -> query($sqlmateria) === TRUE) {
		echo '<script>alert("Materia Actualizada")</script> ';
		echo "<script>location.href='editar_materia.php'</script>";
	}
	else{
		echo '<script>alert("NO SE PUDO REALIZAR LA ACTUALIZACION")</script> ';
}

$conn->close();
?>