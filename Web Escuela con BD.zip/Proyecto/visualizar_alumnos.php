<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Alumnos</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Visualizar Alumnos</h1>
			<h1><small></small></h1>
			<br></br>
		</div>
	</header>

	<form method="POST" action="enviar_visualizar_alumnos.php">

		<div class="container" align="left">
			<br></br>

			<div class="form-group">
    			<label><b>Seleccionar Curso:</b></label>
    			<select name = "CURSO" class="custom-select">   
  				<option value="1A">1A</option>
  				<option value="1B">1B</option>
  				<option value="2A">2A</option>
  				<option value="2B">2B</option>
  				<option value="3A">3A</option>
  				<option value="3B">3B</option>
  				<option value="4A">4A</option>
  				<option value="4B">4B</option>
  				<option value="5A">5A</option>
  				<option value="5B">5B</option>
  				
				</select>
			</div>
			<br></br>
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block">Buscar</button>
			<br></br>
		</div>				  
	</form>

	<br></br>
	<div class="conteiner" align="left">
		<div class="col-md-2" align="left">
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" onclick=" location.href='PropiedadesSecretario.html' ">Volver</button>
		</div>
		<br></br>
		<br></br>
	</div>

	

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>