<?php
require_once("conexion.php");

extract($_GET);
$fecha=date("d/m/Y");
$year=date("Y");

$sqlvincular = "INSERT INTO profesorxmateria (DNI_PROF, ID_MAT, YEAR, FECHA_INICIO) VALUES ('$dni', '$id', '$year', '$fecha')";

if ($conn->query($sqlvincular) === TRUE) {

echo '<script>alert("Profesor asignado correctamente")</script> ';

	} else { 
	echo "Error: ". $sqlvincular . "<br>". $conn->error;
}

$conn->close();
echo "<script>location.href='visualizar_profesores.php'</script>";

?>