<?php
		extract($_GET);
		require("conexion.php");

		$sql="SELECT * FROM materia WHERE ID_MATERIA=$id";
	//la variable  $mysqli viene de connect_db que lo traigo con el require("connect_db.php");
		$ressql=mysqli_query($conn,$sql);
		while ($row=mysqli_fetch_row ($ressql)){
				$id=$row[0];
		    	$materia=$row[1];
		}

?>

<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="UTF-8">
	<title>Editar Materia</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">

</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Editar Materia</h1>
			<h1><small></small></h1>
			<br></br>
		</div>
	</header>

	<form method="POST" action="update_materia.php?id=<?php echo$id; ?>">

		<div class="container" align="left">
			<br></br>
			<label><b>Nombre de la Materia:</b></label>
			<input type="text" value="<?PHP echo $materia ?>" name="MATERIA" required>

			<div class="form-group">
    			<label><b>Seleccionar dia:</b></label>
    			<select name = "DIA" class="custom-select">   
  				<option value="1">Lunes</option>
  				<option value="2">Martes</option>
  				<option value="3">Miercoles</option>
  				<option value="4">Jueves</option>
  				<option value="5">Viernes</option>
				</select>
			</div>

			<div class="form-group">
    			<label><b>Seleccionar horario:</b></label>
    			<select name = "HORARIO" class="custom-select">   
  				<option value="1">7:30 - 9:30</option>
  				<option value="2">10:00 - 12:00</option>
				</select>
			</div>

			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block">Guardar Cambios</button>
			<br></br>
		</div>				  
	</form>

	<div class="conteiner" align="left">
		<div class="col-md-2" align="left">
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" onclick=" location.href='editar_materia.php' ">Volver</button>
		</div>
		<br></br>
	</div>

	
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>