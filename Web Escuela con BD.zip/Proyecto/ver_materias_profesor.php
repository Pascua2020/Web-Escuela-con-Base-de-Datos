<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Materias</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Visualizar Materias</h1>
			<h1><small></small></h1>
			<br></br>
		</div>
	</header>

	<br></br>

	<div class="row" id="ppt">
	<div class="col-md-1" align="left">
			
	</div>
			
		<div class="col-md-10" align="left">

			<?php
				include("conexion.php");
				extract($_GET);
				
				$materias=("SELECT * FROM profesorxmateria, materia, horario, dias WHERE profesorxmateria.ID_MAT = materia.ID_MATERIA AND materia.ID_HS = horario.ID_HORARIO AND materia.ID_DIAS = dias.ID_DIA AND profesorxmateria.DNI_PROF = $dni");	
				$query=mysqli_query($conn,$materias);

					echo "<table border='1'; class='table table-hover';>";
					echo "<tr class='warning'>";
						echo "<th>Materia</th>";
						echo "<th>Dia</th>";
						echo "<th>Horario</th>";
					echo "</tr>";	


				while($arreglo=mysqli_fetch_array($query)){
					if($arreglo[4] == '') {
						echo "<tr class='success'>";
						  	echo "<td>$arreglo[6]</td>";
						  	echo "<td>$arreglo[10]</td>";
						  	echo "<td>$arreglo[12]</td>";
						echo "</tr>";
					}
				}
						

				echo "</table>";
			
			?>
		</div>
		<div class="col-md-1" align="left">
		</div>
	</div>
	<br></br>
	<div class="conteiner" align="left">
		<div class="col-md-2" align="left">
			<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" onclick=" location.href='visualizar_profesores.php ?>' ">Volver</button>
		</div>
		<br></br>
	</div>

	

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>