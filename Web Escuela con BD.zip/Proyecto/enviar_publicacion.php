<?php
require_once("conexion.php");

$sql=("SELECT * FROM sesion_actual, persona WHERE persona.DNI = sesion_actual.DNI_ACTUAL");

$query=mysqli_query($conn,$sql);
while($arreglo=mysqli_fetch_array($query)){
	$dni=$arreglo[1];
}

$publicacion=$_POST['TEXTO'];
$fecha=date("d/m/Y");


		$sqlpublicacion = "INSERT INTO publicacionxsecretario (DNI_P, FECHA_P, PUBLICACION) VALUES ('$dni', '$fecha', '$publicacion')";

		if ($conn->query($sqlpublicacion) === TRUE) {

				echo '<script>alert("Publicacion registrada con exito")</script> ';

			} else { 

			echo "Error: ". $sqlpublicacion . "<br>". $conn->error;

		}


$conn->close();
echo "<script>location.href='PropiedadesSecretario.html'</script>";

?>