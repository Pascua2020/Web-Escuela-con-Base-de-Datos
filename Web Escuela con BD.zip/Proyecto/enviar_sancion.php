<?php
extract($_GET);
require_once("conexion.php");

$sancion=$_POST['TEXTO'];
$fecha=date("d/m/Y");


		$sqlsancion = "INSERT INTO sancionxalumno (DNI_ALUMNO, DESCRIPCION, FECHA) VALUES ('$dni', '$sancion', '$fecha')";

		if ($conn->query($sqlsancion) === TRUE) {

				echo '<script>alert("Sancion Registrada con exito")</script> ';

			} else { 

			echo "Error: ". $sqlsancion . "<br>". $conn->error;

		}


$conn->close();
echo "<script>location.href='PropiedadesSecretario.html'</script>";

?>