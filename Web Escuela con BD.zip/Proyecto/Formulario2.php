<?php
require_once("conexion.php");
//	include (conexion.php);

$apellido=$_POST['APELLIDO'];
		
$nombre=$_POST['NOMBRE'];

$dni=$_POST['DNI'];

$provincia=$_POST['PROVINCIA'];

$direccion=$_POST['DIRECCION'];

$fechanac=$_POST['FECHANAC'];

$categoria=$_POST['CATEGORIA'];

?>

<html>
<head>
	<meta charset="UTF-8">
	<title>Formulario</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-sacle=1.0, maximun-schale=1.0, minimun-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>

	<header>
		<div class="container text-center">
			<br></br>
			<h1>Formulario</h1>
			<h1><small></small></h1>
			<br></br>
		</div>
	</header>


	<?php

		if($categoria == 1){ ?>


			<form method="POST" action="enviar_formulario.php">

				<div class="container" align="left">
					<br></br>
					<label><b>Apellido:</b></label>
					<input type="text" value="<?PHP echo $apellido ?>" name="APELLIDO">

					<label><b>Nombre:</b></label>
					<input type="text" value="<?PHP echo $nombre ?>" name="NOMBRE">

					<label><b>DNI:</b></label>
					<input type="text" value="<?PHP echo $dni ?>" name="DNI">

					<input type="hidden" value="<?PHP echo $provincia ?>" name="PROVINCIA" required>
					<input type="hidden" value="<?PHP echo $direccion ?>" name="DIRECCION"required>
					<input type="hidden" value="<?PHP echo $fechanac ?>" name="FECHANAC"required>
					<input type="hidden" value="<?PHP echo $categoria ?>" name="CATEGORIA"required>

					<br></br>
					<label><b>Titulo:</b></label>
					<input type="text" placeholder="Titulo" name="TITULO"required>

					<label><b>Cargo:</b></label>
					<input type="text" placeholder="Cargo" name="CARGO" required>

					<br></br>
					<INPUT type= "submit" class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block" VALUE= "Aceptar">
					<br></br>
				</div>				  
			</form>
	
	<?php 
		} elseif($categoria == 2){
	?>

			<form method="POST" action="enviar_formulario.php">

				<div class="container" align="left">
					<br></br>
					<label><b>Apellido:</b></label>
					<input type="text" value="<?PHP echo $apellido ?>" name="APELLIDO">

					<label><b>Nombre:</b></label>
					<input type="text" value="<?PHP echo $nombre ?>" name="NOMBRE">

					<label><b>DNI:</b></label>
					<input type="text" value="<?PHP echo $dni ?>" name="DNI">

					<input type="hidden" value="<?PHP echo $provincia ?>" name="PROVINCIA" required>
					<input type="hidden" value="<?PHP echo $direccion ?>" name="DIRECCION"required>
					<input type="hidden" value="<?PHP echo $fechanac ?>" name="FECHANAC"required>
					<input type="hidden" value="<?PHP echo $categoria ?>" name="CATEGORIA"required>
					<br></br>
					<label><b>Titulo:</b></label>
					<input type="text" placeholder="Titulo" name="TITULO"required>

					<label><b>Grado Academico:</b></label>
					<input type="text" placeholder="Grado Academico" name="GRADO" required>

					<br></br>
					<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block">Aceptar</button>
					<br></br>
				</div>				  
			</form>

	<?php 
		} elseif($categoria == 3){
	?>

			<form method="POST" action="enviar_formulario.php">

				<div class="container" align="left">
					<br></br>
					<label><b>Apellido:</b></label>
					<input type="text" value="<?PHP echo $apellido ?>" name="APELLIDO">

					<label><b>Nombre:</b></label>
					<input type="text" value="<?PHP echo $nombre ?>" name="NOMBRE">

					<label><b>DNI:</b></label>
					<input type="text" value="<?PHP echo $dni ?>" name="DNI">

					<input type="hidden" value="<?PHP echo $provincia ?>" name="PROVINCIA" required>
					<input type="hidden" value="<?PHP echo $direccion ?>" name="DIRECCION"required>
					<input type="hidden" value="<?PHP echo $fechanac ?>" name="FECHANAC"required>
					<input type="hidden" value="<?PHP echo $categoria ?>" name="CATEGORIA"required>
					<br></br>
					<label><b>Numero de Legajo:</b></label>
					<input type="text" placeholder="Legajo" name="LEGAJO" required>

					<div class="form-group">
		    			<label><b>Seleccionar curso:</b></label>
		    			<select name = "CURSO" class="custom-select">   
		  				<option value="1A">1A</option>
		  				<option value="1B">1B</option>
		  				<option value="2A">2A</option>
		  				<option value="2B">2B</option>
		  				<option value="3A">3A</option>
		  				<option value="3B">3B</option>
		  				<option value="4A">4A</option>
		  				<option value="4B">4B</option>
		  				<option value="5A">5A</option>
		  				<option value="5B">5B</option>
						</select>
					</div>

					<br></br>
					<button class="btn btn-secondary btn-lg btn-blockbtn-lg btn-block">Aceptar</button>
					<br></br>
				</div>				  
			</form>

	<?php 
		} 
	?>

	
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
<footer align="rigth"><h4><em>Instituto de Formacion Tecnica Superior N°21</em></h4></footer>
</html>